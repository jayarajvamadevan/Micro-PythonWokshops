from machine import Pin, PWM, ADC
from time import sleep
led= Pin(5,Pin.OUT)
frequency = 5000
ledout = PWM(led, frequency)
pot = ADC(0)

while True:
  pot_value = pot.read()
  print(pot_value)
  if pot_value < 15:
    ledout.duty(0)
  else:
    ledout.duty(pot_value)
    sleep(0.1)
