from machine import Pin
import dht
import time
p14=Pin(14, Pin.IN)
d=dht.DHT11(p14)
def play():
    while True:
        d.measure()
        t=d.temperature()
        h=d.humidity()
        print('Temperature=', t, 'C', 'Humidity=', h, '%')
        time.sleep(1) #Delay of 1 second