from machine import Pin
from time import sleep
led = Pin(13, Pin.OUT)
pir = Pin(15, Pin.IN)
while True:
    status=pir.value()
    if status==1:
        print('Motion detected!')
        for x in range(0,10):
            led.on()
            sleep(0.1)
            led.off()
            sleep(0.1)
    elif status==0:
         print('Motion stopped!')
         sleep(1)