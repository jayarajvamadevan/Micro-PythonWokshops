from machine import Pin, SPI
from time import sleep
import random
import time
led=Pin(2,Pin.OUT)
print('demo spi')
gpio_sck = Pin(18)
gpio_mosi = Pin(23)
gpio_miso = Pin(19)
spi = SPI(2, sck=gpio_sck, mosi=gpio_mosi, miso=gpio_miso)
# for x in range(5):
#     led.value(1)
#     spi.write("LED ON")
#     sleep(1)
#     led.value(0)
#     spi.write("LED OFF")
#     sleep(1)
while 1:
    tx = ''.join(chr(random.randint(45,85)) for x in range(4))
    rx = bytearray(4)
    spi.write_readinto(tx,rx)
    print('tx: ' + str(tx))
    print('rx: ' + str(rx))
    time.sleep(2)