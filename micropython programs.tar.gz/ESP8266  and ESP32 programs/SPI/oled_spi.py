import machine
import ssd1306
#spi = machine.SPI(1, baudrate=8000000, polarity=0, phase=0)
spi = SPI(2, baudrate=80000000, polarity=0, phase=0, bits=8, firstbit=0, sck=Pin(18), mosi=Pin(23), miso=Pin(19))
#oled = ssd1306.SSD1306_SPI(128, 64, spi, machine.Pin(4), machine.Pin(5), machine.Pin(15))
oled = ssd1306.SSD1306_SPI(128, 64, spi, machine.Pin(21), machine.Pin(22), machine.Pin(19))
oled.text('Hello, Sivapriya', 0, 0)
oled.text('Hello, Vinayak', 0, 10)
oled.text('Hello, Jayaraj', 0, 20)
        
oled.show()
