from machine import Pin, I2C
import time

PCF8591 = 0x48 # I2C bus address
PCF8591_ADC_CH0 = '\x00' # thermistor
PCF8591_ADC_CH1 = '\x01' #photo-voltaic cell
PCF8591_ADC_CH3 = '\x03' # potentiometer
# cnstruct an I2C bus
gpio_scl = Pin(5)
gpio_sda = Pin(4)
i2c = I2C(scl=Pin(5), sda=Pin(4), freq=100000)
while True:
    i2c.writeto(PCF8591,PCF8591_ADC_CH0)
    data = i2c.readfrom(PCF8591, 1)
    print('Thermistor: ' + str(ord(chr(data[0]))))
# photo-voltaic cell
    i2c.writeto(PCF8591, PCF8591_ADC_CH1)
    i2c.readfrom(PCF8591, 1)
    data = i2c.readfrom(PCF8591, 1)
    print('photo-voltaic: ' +str(ord(chr(data[0]))))
# potentiometer
    i2c.writeto(PCF8591, PCF8591_ADC_CH3)
    i2c.readfrom(PCF8591, 1)
    data = i2c.readfrom(PCF8591, 1)
    print('potentiometer: ' +str(ord(chr(data[0]))))
    time.sleep(2)