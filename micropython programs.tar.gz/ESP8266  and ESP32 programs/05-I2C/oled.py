from machine import Pin, I2C
import ssd1306
from time import sleep
#i2c =I2C(scl=Pin(22), sda=Pin(21))
i2c = I2C(scl=Pin(5), sda=Pin(4))  
oled = ssd1306.SSD1306_I2C(128, 64, i2c, 0x3c)
while True:
# Print the text. 
    oled.fill(0)
    oled.text("Hello World !",20,30)
    oled.show()
    sleep(5)
# Draw an illuminated line.
    oled.fill(0)
    oled.show()
    oled.line (30,50,80,20,1)     
    oled.show ( )
    sleep(5)
# Draw an illuminated horizontal line.  
    oled.fill(0)
    oled.show()
    oled.hline (20,40,80,1 )    
    oled.show () 
    sleep(5)
 # Draw an illuminated vertical line.   
    oled.fill(0)
    oled.show()
    oled.vline (60,10,60,1)    
    oled.show () 
    sleep(5)
# Draw an illuminated rectangle.     
    oled.fill(0)
    oled.show()
    oled.rect (35,20,60,40,1 )    
    oled.show () 
    sleep(5)
# Draw an illuminated filled rectangle.   
    oled.fill(0)
    oled.show()
    oled.fill_rect ( 35,20,60,40,1 ) # Origin (20,10) and width x height 60x40 pixels     
    oled.show() 
    sleep(5)
# Print the text.     
    oled.fill(0)
    oled.show()
    oled.text("End of Show !",20,30)
    oled.show()
    sleep(5)