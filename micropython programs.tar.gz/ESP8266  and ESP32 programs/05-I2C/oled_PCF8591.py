from machine import Pin, I2C
import ssd1306,time
PCF8591 = 0x48 # I2C bus address
PCF8591_ADC_CH0 = '\x00' # thermistor
PCF8591_ADC_CH1 = '\x01' #photo-voltaic cell
PCF8591_ADC_CH3 = '\x03' # potentiometer
# cnstruct an I2C bus
i2c = I2C(scl=Pin(5), sda=Pin(4), freq=100000)
oled=ssd1306.SSD1306_I2C(128,64,i2c,0x3c) 
while True:
    i2c.writeto(PCF8591,PCF8591_ADC_CH0)
    data1 = i2c.readfrom(PCF8591, 1)
    print('Thermistor: ' + str(ord(chr(data1[0]))))
# photo-voltaic cell
    i2c.writeto(PCF8591, PCF8591_ADC_CH1)
    i2c.readfrom(PCF8591, 1)
    data2 = i2c.readfrom(PCF8591, 1)
    print('Photovolt: ' +str(ord(chr(data2[0]))))
# potentiometer
    i2c.writeto(PCF8591, PCF8591_ADC_CH3)
    i2c.readfrom(PCF8591, 1)
    data3 = i2c.readfrom(PCF8591, 1)
    print('potentiometer: ' +str(ord(chr(data3[0]))))
    time.sleep(2)
    oled.fill(0)
    oled.text("Thermistor:",20,10) 
    oled.text(str(data1[0]),100,20)
    oled.text("Photovolt:",20,30)
    oled.text(str(data2[0]),100,40)
    oled.text("Pot:",30,50)
    oled.text(str(data3[0]),100,55)
    oled.show()