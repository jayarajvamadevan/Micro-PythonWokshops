from machine import Pin,PWM
import time
p14 = Pin(14,Pin.OUT)
servo = PWM(p14,freq=50)
for x in range(10):
    for i in range(0,180):
        servo.duty(i)
        time.sleep_ms(10)
        