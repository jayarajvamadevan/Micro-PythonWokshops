from machine import Pin, PWM
from time import sleep
led= Pin(5,Pin.OUT)
frequency = 5000
ledout = PWM(led, frequency)
while True:
  for duty_cycle in range(0, 255,10):
    ledout.duty(duty_cycle)
    sleep(0.1)
