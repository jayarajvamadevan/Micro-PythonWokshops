from machine import Pin,ADC
import time
adc = ADC(0)  # assign to the analog to digital 0 pin
def temp(value):
    return value/10
def fahrenheit(celsius):
    return (celsius * (9/5)) + 32

while True:
    reading = adc.read()
    celsius_temp = temp(reading)
    fahrenheit_temp = fahrenheit(celsius_temp)
    print('Temperature=', celsius_temp , 'C', 'Temperature=',fahrenheit_temp, 'F')
    time.sleep(1)               
