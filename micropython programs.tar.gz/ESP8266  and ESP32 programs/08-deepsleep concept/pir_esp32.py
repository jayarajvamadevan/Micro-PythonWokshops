import machine
import esp32
from machine import Pin
from time import sleep

led = Pin(12, Pin.OUT)
pir = Pin(14, Pin.IN)
while True:
    esp32.wake_on_ext0(pin = pir, level = esp32.WAKEUP_ANY_HIGH)

    print('Motion detected! ')
    for x in range(6):
        led.on()
        sleep(1)
        led.off()
        sleep(1)
    print('Motion stopped!')#your main code goes here to perform a task
    sleep(5)    
    print('Going to sleep now')
    machine.deepsleep()