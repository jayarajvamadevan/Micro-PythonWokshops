# Putting the ESP8266 to Deep sleep and awaking after 10000 milliseconds

import machine
from machine import Pin
from time import sleep

led = Pin(2, Pin.OUT)
 # configure RTC.ALARM0 to be able to wake the device
def deep_sleep(msecs):
    rtc =machine.RTC()
    rtc.irq(trigger=rtc.ALARM0, wake=machine.DEEPSLEEP)
  # USING  RTC.ALARM0 to fire after X milliseconds (waking the device)
    rtc.alarm(rtc.ALARM0, msecs)
  # put the device to sleep
    machine.deepsleep()
print ('Iam Back from Sleep')  
#blinking LED
for x in range(5):
    led.value(1)
    sleep(1)
    led.value(0)
    sleep(1)

print('Im going to sleep')
sleep(5)
deep_sleep(10000)
