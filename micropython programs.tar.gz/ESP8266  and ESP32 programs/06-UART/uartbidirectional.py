from machine import UART,Pin,PWM
import time
#uart = UART(0,9600)#for ESP-8266
uart = UART(2,9600)#for ESP-32
uart.init(9600, bits=8, parity=None, stop=1)
#led= Pin(5,Pin.OUT)#for ESP-8266
led= Pin(22,Pin.OUT)#for ESP-32
uart.write("test""\r\n")
while True:
    if uart.any() >0:
        ch = uart.readline()        
        if ch == b'on':
            led.value(1)
            uart.write("LED ON""\r\n")
        elif ch == b'off':
            led.value(0)
            uart.write("LED OFF""\r\n")  
        else:
            uart.write("You sent wrong code:""\r\n" )
            uart.write(ch)
            uart.write("\r\n")
