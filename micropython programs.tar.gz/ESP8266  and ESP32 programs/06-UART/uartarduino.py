from machine import UART,Pin
import time
#uart = UART(0,9600)#forESP8266
uart = UART(2,9600)#for ESP-32
uart.init(9600, bits=8, parity=None, stop=1)
#led= Pin(5,Pin.OUT)# for ESP8266
led=Pin(22,Pin.OUT)#for ESP32
uart.write("test""\r\n")
time.sleep(2)
for x in range (20):
    led.value(1)
    uart.write("LED ON""\r\n")
    time.sleep(0.8)
    led.value(0)
    uart.write("LED OFF""\r\n")
    time.sleep(0.8)      