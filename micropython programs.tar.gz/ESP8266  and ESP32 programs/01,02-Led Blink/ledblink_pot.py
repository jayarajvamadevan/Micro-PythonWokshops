from machine import Pin, ADC
from time import sleep_ms
led= Pin(5,Pin.OUT)
pot = ADC(0)
while True:
  pot_value = pot.read()
  print(pot_value)
  led.on()
  sleep_ms(pot_value)
  led.off()
  sleep_ms(pot_value)
   
