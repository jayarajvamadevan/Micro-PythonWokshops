from machine import Pin
from time import sleep
ledpin=Pin(2,Pin.OUT)
while True:
    ledpin.on()
    sleep(0.5)
    ledpin.off()
    sleep(0.5)
    